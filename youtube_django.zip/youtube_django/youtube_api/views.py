from django.shortcuts import render
from requests import get, post, put, delete
from json import loads, dumps
import google_auth_oauthlib.flow
from datetime import datetime
import pytz


def store_file(file_name, file_content, write_mode):
    open_file = open(file_name, write_mode)
    open_file.write(file_content)
    open_file.close()


def send_request(method_option, request_url, parameters, input_headers):
    if method_option == "GET":
        response = get(request_url,
                       params=parameters,
                       headers=input_headers)
    elif method_option == "POST":
        response = post(request_url,
                        params=parameters,
                        headers=input_headers)
    elif method_option == "PUT":
        response = put(request_url,
                       params=parameters,
                       headers=input_headers)
    else:
        response = delete(request_url,
                          params=parameters,
                          headers=input_headers)
    return response


def get_headers(client_secrets_file, scopes):
    flow = google_auth_oauthlib.flow.InstalledAppFlow.from_client_secrets_file(
        client_secrets_file, scopes)
    credentials = flow.run_console()
    input_headers = {"Authorization":"Bearer %s"%credentials.token}
    return input_headers


def get_current_time():
    return str(datetime.now(pytz.timezone('Asia/Ho_Chi_Minh')))


def index(request):
    returned_request = request.POST
    context = {}
    if returned_request:
        method_option = returned_request.get("method_option")
        request_url = returned_request.get("request_url")
        parameters = loads(returned_request.get("parameters"))
        scopes = returned_request.get("scopes")
        client_secrets_file = returned_request.get("secret_file")

        current_time = get_current_time()

        try:
            input_headers = get_headers(client_secrets_file, scopes)
            response = send_request(method_option, request_url, parameters, input_headers)
        except Exception as error:
            store_file("error_log.txt", current_time + "-->" + str(error) + "\n", "a")
            context = {"response": "!! ERROR:" + str(error)}
            return render(request, 'youtube_api/index.html', context)

        response_to_user = response.text
        response_type = response.headers["Content-Type"].split("/")[1].split(";")[0]
        context = {"response": response_to_user}

        if "error" in loads(response.text):
            store_file("error_log.txt",current_time + "-->" + response_to_user + "\n", "a")
        else:
            store_file("last_response_data." + response_type, response_to_user, "w+")

    return render(request, 'youtube_api/index.html', context)
