from django.apps import AppConfig


class YoutubeApiConfig(AppConfig):
    name = 'youtube_api'
